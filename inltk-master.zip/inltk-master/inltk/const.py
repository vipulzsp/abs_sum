tokenizer_special_cases = [
    'xxbos',
    'xxeos',
]
