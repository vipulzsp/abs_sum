.. iNLTK documentation master file, created by
   sphinx-quickstart on Sat Dec 14 17:08:36 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Natural Language Toolkit for Indic Languages
===================================================

iNLTK aims to provide out of the box support for various NLP tasks that an application developer might need

.. toctree::
   :maxdepth: 3

   api_docs.md

